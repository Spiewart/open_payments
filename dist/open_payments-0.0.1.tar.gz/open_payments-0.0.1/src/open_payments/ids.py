from enum import StrEnum
from itertools import combinations
from typing import Literal, Union

import pandas as pd

from .citystates import PaymentCityStates
from .credentials import PaymentCredentials
from .helpers import str_in_str
from .physicians_only import PhysicianFilter
from .read import ReadPayments
from .specialtys import PaymentSpecialtys


class PaymentIDs(
    PaymentSpecialtys,
    PaymentCredentials,
    PaymentCityStates,
    ReadPayments,
):

    def __init__(
        self,
        MD_DO_only: bool = True,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.MD_DO_only = MD_DO_only

    def unique_payments(self) -> pd.DataFrame:
        """Returns a DataFrame of rows from OpeyPayments payment datasets that
        have a unique provider ID (Covered_Recipient_Profile_ID)."""

        all_payments = self.all_payments()

        # Remove duplicates again because there may be duplicate IDs between
        # the three different payment types.
        all_payments = self.remove_duplicate_ids(all_payments)

        all_payments.drop("payment_class", axis=1, inplace=True)

        return all_payments

    def update_payments(
        self,
        payment_class: Literal["general", "ownership", "research"],
    ) -> pd.DataFrame:
        """Removes duplicate IDs and renames columns for the payment class
        DataFrame."""

        if self.MD_DO_only:
            payments = PhysicianFilter(
                payments=getattr(
                    self,
                    f"{payment_class}_payments",
                )
            ).filter()

        payments = super().update_payments(payment_class)

        payments = self.post_update_payments_mod(payments)

        return payments

    def post_update_payments_mod(self, payments: pd.DataFrame) -> pd.DataFrame:
        """Method that is called after the update_payments method."""

        payments = self.remove_duplicate_ids(payments)
        payments = self.specialtys(payments)
        payments = self.credentials(payments)
        payments = self.citystates(payments)
        return payments

    def update_ownership_payments(self) -> pd.DataFrame:
        """Updates ownership payments and returns the updated DataFrame."""
        self.ownership_payments = super().update_ownership_payments()
        return self.ownership_payments

    @staticmethod
    def remove_duplicate_ids(df: pd.DataFrame) -> pd.DataFrame:
        """Method that removes duplicate Covered_Recipient_Profile_IDs
        from the DataFrame."""

        df.reset_index(inplace=True, drop=True)

        df = df[
            df["profile_id"].isnull()
            | ~df[
                df['profile_id'].notnull()
            ].duplicated(subset='profile_id', keep='first')
        ]

        return df


class PaymentFilters(StrEnum):
    """Enum class for the various stages at which a conflicted provider
    can be identified from the list of unique OpenPayment IDs."""

    LASTNAME = "LASTNAME"
    FIRSTNAME = "FIRSTNAME"
    CREDENTIAL = "CREDENTIAL"
    SPECIALTY = "SPECIALTY"
    SUBSPECIALTY = "SUBSPECIALTY"
    FULLSPECIALTY = "FULLSPECIALTY"  # Matches specialty and subspecialty
    MIDDLE_INITIAL = "MIDDLE_INITIAL"
    MIDDLENAME = "MIDDLENAME"
    CITY = "CITY"
    STATE = "STATE"
    CITYSTATE = "CITYSTATE"  # Matches city and state


class Unmatcheds(StrEnum):
    """Enum class to represent the various ways a conflicted can
    remain unmatched throughout / after the filtering process."""

    NOLASTNAME = "NOLASTNAME"  # No matches for the last name in OpenPayments
    UNFILTERABLE = "UNFILTERABLE"  # Multiple OpenPayments IDs that can't be matched


def get_list_of_combinations(input_list: list[PaymentFilters]) -> list[list[PaymentFilters]]:
    """
    Generates all combinations of PaymentFilters from the input list.

    Args:
        input_list: The list PaymetnIDFilters to generate combinations from.

    Returns:
        A list of lists of PaymentFilters, where each list is a combination.
    """
    all_combinations = []
    for r in range(1, len(input_list) + 1):
        for combination in combinations(input_list, r):
            all_combinations.append(list(combination))
    return all_combinations


class ConflictedPaymentIDs(PaymentIDs):

    def __init__(
        self,
        conflicteds: pd.DataFrame,
        payments: Union[pd.DataFrame, None],
        *args,
        **kwargs,
    ):
        """Filters OpenPayments profile IDs by .

        conflicteds[DataFrame]:
        -provider_pk: Int64
        -first_name: str
        -last_name: str
        -middle_initial_1: str
        -middle_initial_2: str
        -middle_name_1: str
        -middle_name_2: str
        -credentials: array[Credentials]
        -specialtys: array[Specialtys]
        -citystates: array[CityState]

        payments[DataFrame]:
        -profile_id: Int64
        -first_name: str
        -middle_name: str
        -last_name: str
        -specialtys: array[Specialtys]
        -credentials: array[Credentials]
        -citystates: array[CityState]

        """
        super().__init__(*args, **kwargs)
        self.conflicteds = conflicteds

        self.conflicteds = self.add_conflict_prefix(self.conflicteds)
        self.num_conflicteds = self.conflicteds["conflict_provider_pk"].nunique()
        self.payments = payments
        self.payments_x_conflicteds = pd.DataFrame()
        self.unmatched = pd.DataFrame()
        self.unique_ids = pd.DataFrame()

    @staticmethod
    def add_conflict_prefix(
        conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Adds the conflict_ prefix to each
        conflicteds column other than last_name."""

        conflicteds = conflicteds.rename(
            columns={
                col: f"conflict_{col}" for col in conflicteds.columns if col != "last_name"
            }
        )
        return conflicteds

    def conflicteds_payments_ids(
        self,
        filters: list[PaymentFilters] = None,
    ) -> pd.DataFrame:
        """Method that returns a DataFrame of payment IDs for conflicteds."""

        if filters is None:
            filters = PaymentFilters.__members__.values()

        if self.payments is None:
            self.payments = self.unique_payments()

        # Eliminates payments that don't have a last name match in conflicteds
        # Retains conflicteds that don't have a last name match in payments
        self.payments_x_conflicteds = pd.concat(
            [self.payments_x_conflicteds, self.merge_by_last_name(
                payments=self.payments,
                conflicteds=self.conflicteds,
            )]
        )

        # Filter out conflicteds that have no last name match in payments
        self.update_unmatched(
            unmatcheds=self.payments_x_conflicteds[
                self.payments_x_conflicteds["profile_id"].isna()
            ],
            unmatched=Unmatcheds.NOLASTNAME,
        )

        filter_combos = get_list_of_combinations(filters)

        # Organize filters by most specific (longest) to least specific (shortest)
        # to ensure that the most specific filters are applied first
        filter_combos = sorted(
            filter_combos,
            key=len,
            reverse=True,
        )

        for filter_combo in filter_combos:
            if self.payments_x_conflicteds.empty:
                break
            self.filter_and_update_unique_ids(
                payments_x_conflicteds=self.payments_x_conflicteds,
                payment_filters=filter_combo,
            )
            self.check_sanity()

        # TODO: Check all the LASTNAME matches for secondary matches with other columns
        return self.unique_ids

    @staticmethod
    def merge_by_last_name(
        payments: pd.DataFrame,
        conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Merges conflicteds with payments DataFrames
        by last name. Returns tuple of DataFrames:
        - conflicteds x payments matched by last name
        - conflicteds that did not match by last name"""

        print("Merging Payments df with Conflicteds df by last name...")

        payments["last_name"] = payments["last_name"].str.lower()
        conflicteds["last_name"] = conflicteds["last_name"].str.lower()

        crossed = payments.merge(
            right=conflicteds,
            on="last_name",
            how="right",
        )

        crossed["last_name"] = crossed["last_name"].str.capitalize()
        payments["last_name"] = payments["last_name"].str.capitalize()
        conflicteds["last_name"] = conflicteds["last_name"].str.capitalize()

        return crossed

    def update_unmatched(
        self,
        unmatcheds: pd.DataFrame,
        unmatched: Unmatcheds,
    ) -> None:

        print(f"Updating unmatched IDs with {unmatcheds.shape[0]} conflicted providers...")

        unmatcheds = self.remove_duplicate_ids(unmatcheds)

        unmatcheds = self.conflicteds[
            self.conflicteds["conflict_provider_pk"].isin(unmatcheds["conflict_provider_pk"])
        ]

        unmatcheds = self.remove_conflict_prefix(unmatcheds)

        unmatcheds["unmatched"] = unmatched

        self.unmatched = pd.concat(
            [self.unmatched, unmatcheds]
        )

        self.payments_x_conflicteds = self.payments_x_conflicteds[
            self.payments_x_conflicteds["profile_id"].notna()
        ]

    def filter_and_update_unique_ids(
        self,
        payments_x_conflicteds: pd.DataFrame,
        payment_filters: list[PaymentFilters],
    ) -> None:
        """Filters the payments x conflicteds DataFrame
        by the given filters and updates the unique_ids DataFrame
        with the new unique IDs."""

        print(f"Applying {payment_filters} filters to payments x conflicteds DataFrame...")

        filtered_payments = self.payment_filter(
            payments_x_conflicteds=payments_x_conflicteds,
            payment_filters=payment_filters,
        )

        self.extract_and_update_unique_ids(
            filtered_payments=filtered_payments,
            payment_filters=payment_filters,
        )

    def payment_filter(
        self,
        payments_x_conflicteds: pd.DataFrame,
        payment_filters: list[PaymentFilters],
    ) -> pd.DataFrame:
        for payment_filter in payment_filters:
            payments_x_conflicteds = getattr(
                self,
                f"filter_by_{payment_filter.lower()}",
            )(
                payments_x_conflicteds=payments_x_conflicteds,
            ) if not payments_x_conflicteds.empty else payments_x_conflicteds

        return payments_x_conflicteds

    def extract_and_update_unique_ids(
        self,
        filtered_payments: pd.DataFrame,
        payment_filters: list[PaymentFilters],
    ) -> Union[pd.DataFrame, None]:
        """Extracts unique IDs from the payments x conflicteds DataFrame
        and updates the unique_ids DataFrame with the new unique IDs."""

        if not filtered_payments.empty:
            new_unique_ids = self.extract_unique_ids(
                payments_x_conflicteds=filtered_payments,
            )
            self.update_ids(
                new_unique_ids=new_unique_ids,
                filters=payment_filters,
            )
            return filtered_payments
        else:
            return None

    @classmethod
    def extract_unique_ids(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Extracts unique IDs from the payments x conflicteds DataFrame
        and returns a DataFrame with the unique IDs."""

        unique_ids = pd.DataFrame()

        for provider_pk in payments_x_conflicteds["conflict_provider_pk"].unique():
            provider_rows = payments_x_conflicteds[
                payments_x_conflicteds["conflict_provider_pk"] == provider_pk
            ]

            # Remove rows with no profile_id
            provider_rows = provider_rows[
                provider_rows["profile_id"].notna()
            ]

            # Remove duplicate profile_id rows
            provider_rows = cls.remove_duplicate_ids(provider_rows)

            if len(provider_rows) == 1:
                unique_ids = pd.concat([unique_ids, provider_rows])

        return unique_ids

    def update_ids(
        self,
        new_unique_ids: pd.DataFrame,
        filters: list[PaymentFilters],
    ) -> None:
        """Extracts unique provider_pks from the payments DataFrame
        and adds them to the unique_ids DataFrame."""

        if not new_unique_ids.empty:
            # https://stackoverflow.com/questions/69799736/join-an-array-to-every-row-in-the-pandas-dataframe
            new_unique_ids = self.add_filters_column(new_unique_ids, filters)

            self.unique_ids = pd.concat([self.unique_ids, new_unique_ids])
            self.payments_x_conflicteds = self.payments_x_conflicteds.drop(
                self.payments_x_conflicteds[
                    self.payments_x_conflicteds[
                        "conflict_provider_pk"
                    ].isin(new_unique_ids["conflict_provider_pk"])
                ].index
            )

    @staticmethod
    def add_filters_column(df: pd.DataFrame, filters: list[PaymentFilters]) -> pd.DataFrame:
        """Adds a filters column to the DataFrame."""
        df.insert(0, "filters", [filters] * len(df))
        return df

    @staticmethod
    def remove_conflict_prefix(
        conflicteds_x_payments: pd.DataFrame,
    ) -> pd.DataFrame:
        """Removes the conflict_ prefix from the columns
        of the conflicteds x payments DataFrame."""

        conflicteds_x_payments = conflicteds_x_payments.rename(
            columns={
                col: col.replace("conflict_", "")
                for col in conflicteds_x_payments.columns
                if col.startswith("conflict_")
            }
        )

        return conflicteds_x_payments

    def check_sanity(self) -> None:
        # Sanity check to ensure no loss of conflicteds

        assert (
            self.num_conflicteds
            ==
            (
                (
                    self.unmatched["provider_pk"].nunique(dropna=True)
                    if not self.unmatched.empty else 0
                )
                + (len(self.unique_ids) if not self.unique_ids.empty else 0)
                + (
                    self.payments_x_conflicteds[
                        "conflict_provider_pk"
                    ].nunique(dropna=True)
                    if not self.payments_x_conflicteds.empty else 0
                )
            )
        )

    @classmethod
    def filter_by_lastname(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters a payments DataFrame merged with a
        conflicteds DataFrame by removing rows that
        do not have a last name match."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                pd.notna(row["last_name"])
            ),
            axis=1,
        )]

    @classmethod
    def filter_by_credential(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters a payments DataFrame merged with a
        conflicteds DataFrame by removing rows that
        do not have a credential match."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                any(
                    cred in row["credentials"]
                    for cred in row["conflict_credentials"]
                ) if (
                    cls.empty_array_or_nan_can_be_iterated(row["credentials"])
                    and cls.empty_array_or_nan_can_be_iterated(row["conflict_credentials"])
                ) else False
            ),
            axis=1,
        )]

    @classmethod
    def filter_by_firstname(
        cls,
        payments_x_conflicteds: pd.DataFrame,
        strict: bool = False,
    ) -> pd.DataFrame:
        """Filters a payments DataFrame merged with a
        conflicteds DataFrame by removing rows that
        do not have a first name match."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                pd.notna(row["first_name"])
                and pd.notna(row["conflict_first_name"])
                and row["first_name"] == row["conflict_first_name"] if strict else (
                    pd.notna(row["first_name"])
                    and pd.notna(row["conflict_first_name"])
                    and (
                        str_in_str(row["first_name"], row["conflict_first_name"])
                        or str_in_str(row["conflict_first_name"], row["first_name"])
                    )
                )
            ),
            axis=1,
        )]

    @classmethod
    def filter_by_specialty(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by specialty."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                cls.payment_conflict_specialty_match(
                    payment_specialtys=row["specialtys"],
                    conflict_specialtys=row["conflict_specialtys"],
                )
            ),
            axis=1,
        )]

    @classmethod
    def payment_conflict_specialty_match(
        cls,
        payment_specialtys: Union[list[PaymentSpecialtys], None],
        conflict_specialtys: Union[list[PaymentSpecialtys], None],
    ) -> bool:
        """Checks if there is a specialty conflict."""

        return any(
            spec.specialty in [
                spec.specialty for spec in payment_specialtys if pd.notna(spec)
            ] for spec in [
                spec for spec in conflict_specialtys if pd.notna(spec)
            ]
        ) if cls.empty_array_or_nan_can_be_iterated(payment_specialtys) and cls.empty_array_or_nan_can_be_iterated(conflict_specialtys) else False

    @classmethod
    def filter_by_subspecialty(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by subspecialty."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                cls.payment_conflict_subspecialty_match(
                    payment_specialtys=row["specialtys"],
                    conflict_specialtys=row["conflict_specialtys"],
                )
            ),
            axis=1,
        )]

    @classmethod
    def payment_conflict_subspecialty_match(
        cls,
        payment_specialtys: Union[list[PaymentSpecialtys], None],
        conflict_specialtys: Union[list[PaymentSpecialtys], None],
    ) -> bool:

        return any(
            spec.subspecialty in [
                spec.subspecialty for spec in payment_specialtys if pd.notna(spec)
            ] for spec in [
                spec for spec in conflict_specialtys if pd.notna(spec)
            ]
        ) if cls.empty_array_or_nan_can_be_iterated(payment_specialtys) and cls.empty_array_or_nan_can_be_iterated(conflict_specialtys) else False

    @classmethod
    def filter_by_fullspecialty(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by full specialty."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                cls.payment_conflict_full_specialty_match(
                    payment_specialtys=row["specialtys"],
                    conflict_specialtys=row["conflict_specialtys"],
                )
            ),
            axis=1,
        )]

    @classmethod
    def payment_conflict_full_specialty_match(
        cls,
        payment_specialtys: Union[list[PaymentSpecialtys], None],
        conflict_specialtys: Union[list[PaymentSpecialtys], None],
    ) -> bool:

        return any(
            spec in [
                spec for spec in payment_specialtys if pd.notna(spec)
            ] for spec in [
                spec for spec in conflict_specialtys if pd.notna(spec)
            ]
        ) if cls.empty_array_or_nan_can_be_iterated(payment_specialtys) and cls.empty_array_or_nan_can_be_iterated(conflict_specialtys) else False

    @classmethod
    def filter_by_city(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by city."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                cls.payment_conflict_city_match(
                    payment_citystates=row["citystates"],
                    conflict_citystates=row["conflict_citystates"],
                )
            ),
            axis=1,
        )]

    @classmethod
    def payment_conflict_city_match(
        cls,
        payment_citystates: Union[list[PaymentSpecialtys], None],
        conflict_citystates: Union[list[PaymentSpecialtys], None],
    ) -> bool:

        return any(
            citystate.city in [
                citystate.city for citystate in payment_citystates
                if pd.notna(citystate)
            ] for citystate in [
                citystate for citystate in conflict_citystates
                if pd.notna(citystate)
            ]
        ) if (
            cls.empty_array_or_nan_can_be_iterated(payment_citystates)
            and cls.empty_array_or_nan_can_be_iterated(conflict_citystates)
        ) else False

    @staticmethod
    def empty_array_or_nan_can_be_iterated(
        row: Union[list, float]
    ) -> bool:
        """Checks if the citystates can be iterated over."""

        return isinstance(row, list) and row

    @classmethod
    def filter_by_state(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by state."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                cls.payment_conflict_state_match(
                    payment_citystates=row["citystates"],
                    conflict_citystates=row["conflict_citystates"],
                )
            ),
            axis=1,
        )]

    @classmethod
    def payment_conflict_state_match(
        cls,
        payment_citystates: Union[list[PaymentSpecialtys], None],
        conflict_citystates: Union[list[PaymentSpecialtys], None],
    ) -> bool:

        return any(
            citystate.state in [
                citystate.state for citystate in payment_citystates
                if pd.notna(citystate)
            ] for citystate in [
                citystate for citystate in conflict_citystates
                if pd.notna(citystate)
            ]
        ) if (
            cls.empty_array_or_nan_can_be_iterated(payment_citystates)
            and cls.empty_array_or_nan_can_be_iterated(conflict_citystates)
        ) else False

    @classmethod
    def filter_by_citystate(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by city and state."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                cls.payment_conflict_citystate_match(
                    payment_citystates=row["citystates"],
                    conflict_citystates=row["conflict_citystates"],
                )
            ),
            axis=1,
        )]

    @classmethod
    def payment_conflict_citystate_match(
        cls,
        payment_citystates: Union[list[PaymentSpecialtys], None],
        conflict_citystates: Union[list[PaymentSpecialtys], None],
    ) -> bool:

        return any(
            citystate in [
                citystate for citystate in payment_citystates
                if pd.notna(citystate)
            ] for citystate in [
                citystate for citystate in conflict_citystates
                if pd.notna(citystate)
            ]
        ) if (
            cls.empty_array_or_nan_can_be_iterated(payment_citystates)
            and cls.empty_array_or_nan_can_be_iterated(conflict_citystates)
        ) else False

    @classmethod
    def filter_by_middle_initial(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by middle initial."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: cls.middle_initial_match(
                conflicted_middle_initial_1=row["conflict_middle_initial_1"],
                conflicted_middle_initial_2=row["conflict_middle_initial_2"],
                conflicted_middle_name_1=row["conflict_middle_name_1"],
                conflicted_middle_name_2=row["conflict_middle_name_2"],
                payment_middle_name=row["middle_name"],
                ),
            axis=1,
        )]

    @staticmethod
    def middle_initial_match(
        conflicted_middle_initial_1: Union[str, None],
        conflicted_middle_initial_2: Union[str, None],
        conflicted_middle_name_1: Union[str, None],
        conflicted_middle_name_2: Union[str, None],
        payment_middle_name: Union[str, None],
    ) -> bool:
        """Checks if the middle initial matches."""

        return pd.notna(payment_middle_name) and (
            (
                pd.notna(conflicted_middle_initial_1)
                and payment_middle_name[0].lower() == conflicted_middle_initial_1.lower()
            )
            or (
                pd.notna(conflicted_middle_initial_2)
                and payment_middle_name[0].lower() == conflicted_middle_initial_2.lower()
            )
            or (
                pd.notna(conflicted_middle_name_1)
                and payment_middle_name.lower() == conflicted_middle_name_1[0].lower()
            )
            or (
                pd.notna(conflicted_middle_name_2)
                and payment_middle_name.lower() == conflicted_middle_name_2[0].lower()
            )
        )

    @classmethod
    def filter_by_middlename(
        cls,
        payments_x_conflicteds: pd.DataFrame,
    ) -> pd.DataFrame:
        """Filters by middle name."""

        return payments_x_conflicteds[payments_x_conflicteds.apply(
            lambda row: (
                cls.middlename_match(
                    conflicted_middle_name_1=row["conflict_middle_name_1"],
                    conflicted_middle_name_2=row["conflict_middle_name_2"],
                    payment_middle_name=row["middle_name"],
                )
            ),
            axis=1,
        )]

    @staticmethod
    def middlename_match(
        conflicted_middle_name_1: Union[str, None],
        conflicted_middle_name_2: Union[str, None],
        payment_middle_name: Union[str, None],
    ) -> bool:
        """Checks if the middle name matches."""

        return pd.notna(payment_middle_name) and (
            (
                pd.notna(conflicted_middle_name_1)
                and payment_middle_name.lower() == conflicted_middle_name_1.lower()
            )
            or (
                pd.notna(conflicted_middle_name_2)
                and payment_middle_name.lower() == conflicted_middle_name_2.lower()
            )
        )