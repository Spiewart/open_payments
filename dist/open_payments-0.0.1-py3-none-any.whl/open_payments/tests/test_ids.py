import unittest

import pandas as pd

from ..citystates import CityState
from ..credentials import Credentials
from ..ids import ConflictedPaymentIDs, PaymentFilters, PaymentIDs, Unmatcheds
from ..specialtys import Specialtys


class TestPaymentIDs(unittest.TestCase):

    def test__unique_payments(self):
        unique_payments = PaymentIDs(payment_classes="general").unique_payments()

        self.assertIsInstance(unique_payments, pd.DataFrame)
        self.assertIn("profile_id", unique_payments.columns)
        self.assertIn("npi", unique_payments.columns)
        self.assertIn("first_name", unique_payments.columns)
        self.assertIn("middle_name", unique_payments.columns)
        self.assertIn("last_name", unique_payments.columns)
        self.assertIn("specialtys", unique_payments.columns)
        self.assertIn("credentials", unique_payments.columns)
        self.assertIn("citystates", unique_payments.columns)
        self.assertEqual(len(unique_payments.columns), 8)


def add_conflicted_to_conflicteds_df(
    conflicteds: pd.DataFrame,
    provider_pk: int,
    first_name: str,
    last_name: str,
    middle_initial_1: str,
    middle_initial_2: str,
    middle_name_1: str,
    middle_name_2: str,
    credentials: list,
    specialtys: list,
    citystates: list,
) -> pd.DataFrame:
    """
    Add conflicted information to the conflicteds DataFrame.
    """

    conflicteds = pd.concat(
        [
            conflicteds,
            pd.DataFrame({
                "provider_pk": provider_pk,
                "first_name": first_name,
                "last_name": last_name,
                "middle_initial_1": middle_initial_1,
                "middle_initial_2": middle_initial_2,
                "middle_name_1": middle_name_1,
                "middle_name_2": middle_name_2,
                "credentials": credentials,
                "specialtys": specialtys,
                "citystates": citystates,
            })
        ],
        ignore_index=True
    )

    return conflicteds


def add_payment_id_to_payments_df(
    payments: pd.DataFrame,
    profile_id: int,
    first_name: str,
    middle_name: str,
    last_name: str,
    specialtys: list,
    credentials: list,
    citystates: list,
) -> pd.DataFrame:
    """
    Add a new payment ID to the payments DataFrame.
    """

    payments = pd.concat(
        [
            payments,
            pd.DataFrame({
                "profile_id": profile_id,
                "first_name": first_name,
                "middle_name": middle_name,
                "last_name": last_name,
                "specialtys": specialtys,
                "credentials": credentials,
                "citystates": citystates,
            }),
        ],
        ignore_index=True
    )

    return payments


class TestConflictedPaymentIDs(unittest.TestCase):
    def setUp(self):
        self.fake_conflicteds = pd.DataFrame({
                "provider_pk": [1, 2, 3, 4],
                "first_name": ["John", "Judd", "Joey", "Dave"],
                "last_name": ["Doe", "Smith", "Johnson", "Ebalt"],
                "middle_initial_1": ["A", "E", "C", "Z"],
                "middle_initial_2": [None, None, None, None],
                "middle_name_1": ["Alpha", None, None, "Clark"],
                "middle_name_2": [None, "Echo", None, None],
                "credentials": [
                    [Credentials.MEDICAL_DOCTOR],
                    [Credentials.DOCTOR_OF_OSTEOPATHY],
                    [Credentials.MEDICAL_DOCTOR],
                    [Credentials.MEDICAL_DOCTOR],
                ],
                "specialtys": [
                    [Specialtys(specialty="Pediatrics", subspecialty="Gastroenterology")],
                    [Specialtys(specialty="Family Medicine")],
                    [Specialtys(specialty="Internal Medicine")],
                    [
                        Specialtys(specialty="Internal Medicine", subspecialty="Rheumatology"),
                        Specialtys(specialty="Internal Medicine", subspecialty="Chief Resident")
                    ]
                ],
                "citystates": [
                    [CityState(city="New York", state="NY")],
                    [CityState(city="Los Angeles", state="NV")],
                    [CityState(city="Chicago", state="IL")],
                    [CityState(city="Saint Paul", state="MN")]
                ],
            })

        self.fake_payments = pd.DataFrame({
            "profile_id": [1, 2, 3],
            "first_name": ["John", "Jane", "Joe"],
            "middle_name": ["Alpha", "Edward", None],
            "last_name": ["Doe", "Smith", "Johnson"],
            "specialtys": [
                [Specialtys(specialty="Pediatrics", subspecialty="Neonatology")],
                [Specialtys(specialty="Surgery")],
                [Specialtys(specialty="Internal Medicine")]
            ],
            "credentials": [
                [Credentials.MEDICAL_DOCTOR],
                [Credentials.DOCTOR_OF_OSTEOPATHY],
                [Credentials.PHYSICIAN_ASSISTANT]
            ],
            "citystates": [
                [CityState(city="New York", state="NY")],
                [CityState(city="Los Angeles", state="CA")],
                [CityState(city="Rochester", state="IL")]
            ],
        })
        self.reader_fake = ConflictedPaymentIDs(
            self.fake_conflicteds,
            self.fake_payments
        )

    def test__unique_payments(self):
        unique_payemnt_ids = ConflictedPaymentIDs(
            conflicteds=self.fake_conflicteds,
            payments=None,
            nrows=1000,
            years=2023,
        ).unique_payments()

        self.assertIsInstance(unique_payemnt_ids, pd.DataFrame)
        self.assertIn("specialtys", unique_payemnt_ids.columns)
        self.assertIn("citystates", unique_payemnt_ids.columns)
        self.assertIn("citystates", unique_payemnt_ids.columns)

    def test__add_conflict_prefix(self):
        updated_conflicteds = self.reader_fake.add_conflict_prefix(self.fake_conflicteds)

        self.assertIn("conflict_first_name", updated_conflicteds.columns)
        self.assertIn("conflict_middle_initial_1", updated_conflicteds.columns)
        self.assertIn("conflict_middle_initial_2", updated_conflicteds.columns)
        self.assertIn("conflict_middle_name_1", updated_conflicteds.columns)
        self.assertIn("conflict_middle_name_2", updated_conflicteds.columns)
        self.assertIn("conflict_credentials", updated_conflicteds.columns)
        self.assertIn("conflict_specialtys", updated_conflicteds.columns)
        self.assertIn("conflict_citystates", updated_conflicteds.columns)

    def test__conflicteds_payments_ids(self):
        # Test with fake conflicteds
        reader_fake = ConflictedPaymentIDs(conflicteds=self.fake_conflicteds, payments=self.fake_payments)
        conflicteds = reader_fake.conflicteds_payments_ids()
        self.assertIsInstance(conflicteds, pd.DataFrame)

        # Test with real conflicteds
        reader_real = ConflictedPaymentIDs(conflicteds=self.fake_conflicteds, payments=None, nrows=10000, years=2023)

        conflicteds = reader_real.conflicteds_payments_ids()

        self.assertIsInstance(conflicteds, pd.DataFrame)

        self.assertIn("profile_id", conflicteds.columns)
        self.assertIn("citystates", conflicteds.columns)
        self.assertIn("credentials", conflicteds.columns)
        self.assertIn("specialtys", conflicteds.columns)
        self.assertIn("first_name", conflicteds.columns)
        self.assertIn("middle_name", conflicteds.columns)
        self.assertIn("last_name", conflicteds.columns)
        self.assertIn("conflict_provider_pk", conflicteds.columns)
        self.assertIn("conflict_first_name", conflicteds.columns)
        self.assertIn("conflict_middle_initial_1", conflicteds.columns)
        self.assertIn("conflict_middle_initial_2", conflicteds.columns)
        self.assertIn("conflict_middle_name_1", conflicteds.columns)
        self.assertIn("conflict_middle_name_2", conflicteds.columns)
        self.assertIn("conflict_credentials", conflicteds.columns)
        self.assertIn("conflict_specialtys", conflicteds.columns)
        self.assertIn("conflict_citystates", conflicteds.columns)
        self.assertIn("filters", conflicteds.columns)

        self.assertIn("unmatched", reader_real.unmatched.columns)

    def test__merge_by_lastname(self):
        # Add more mock data to payments
        extra_mock_data = [
            [4, "Nathan", "EG", "Doe", [Specialtys(specialty="Pediatrics")], [Credentials.MEDICAL_DOCTOR], [CityState(city="New York", state="NY")]],
            [5, "Handsy", None, "Doe", [Specialtys(specialty="Pediatrics")], [Credentials.MEDICAL_DOCTOR], [CityState(city="New York", state="NY")]],
            [6, "Johnson", "C", "Doe", [Specialtys(specialty="Pediatrics")], [Credentials.MEDICAL_DOCTOR], [CityState(city="New York", state="NY")]],
        ]

        for data in extra_mock_data:
            self.fake_payments = add_payment_id_to_payments_df(
                self.fake_payments,
                *data
            )

        merged = self.reader_fake.merge_by_last_name(
            payments=self.fake_payments,
            conflicteds=self.reader_fake.conflicteds,
        )

        self.assertIsInstance(merged, pd.DataFrame)
        self.assertIn("profile_id", merged.columns)
        self.assertIn("first_name", merged.columns)
        self.assertIn("middle_name", merged.columns)
        self.assertIn("last_name", merged.columns)
        self.assertIn("specialtys", merged.columns)
        self.assertIn("credentials", merged.columns)
        self.assertIn("citystates", merged.columns)
        self.assertIn("conflict_provider_pk", merged.columns)
        self.assertIn("conflict_first_name", merged.columns)
        self.assertIn("conflict_middle_initial_1", merged.columns)
        self.assertIn("conflict_middle_initial_2", merged.columns)
        self.assertIn("conflict_middle_name_1", merged.columns)
        self.assertIn("conflict_middle_name_2", merged.columns)
        self.assertIn("conflict_credentials", merged.columns)
        self.assertIn("conflict_specialtys", merged.columns)
        self.assertIn("conflict_citystates", merged.columns)
        self.assertEqual(len(merged.columns), 16)

        self.assertEqual(len(merged), 7)

    def test__update_ids(self):
        self.reader_fake.payments_x_conflicteds = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )
        self.reader_fake.update_ids(
            new_unique_ids=self.reader_fake.extract_unique_ids(
                self.reader_fake.payments_x_conflicteds,
            ),
            filters=[PaymentFilters.LASTNAME],
        )
        self.assertIsInstance(self.reader_fake.unique_ids, pd.DataFrame)
        self.assertIn("profile_id", self.reader_fake.unique_ids.columns)
        self.assertIn("first_name", self.reader_fake.unique_ids.columns)
        self.assertIn("middle_name", self.reader_fake.unique_ids.columns)
        self.assertIn("last_name", self.reader_fake.unique_ids.columns)
        self.assertIn("specialtys", self.reader_fake.unique_ids.columns)
        self.assertIn("credentials", self.reader_fake.unique_ids.columns)
        self.assertIn("citystates", self.reader_fake.unique_ids.columns)
        self.assertIn("filters", self.reader_fake.unique_ids.columns)

        self.assertFalse(self.reader_fake.unique_ids.empty)
        self.assertEqual(len(self.reader_fake.unique_ids), 3)
        # Test that each row has a filter applied
        for i in self.reader_fake.unique_ids.index:
            row = self.reader_fake.unique_ids.iloc[i]
            self.assertIn(PaymentFilters.LASTNAME, row["filters"])
            self.assertEqual(len(row["filters"]), 1)
        self.assertIn("Doe", self.reader_fake.unique_ids["last_name"].values.tolist())
        self.assertIn("Smith", self.reader_fake.unique_ids["last_name"].values.tolist())
        self.assertIn("Johnson", self.reader_fake.unique_ids["last_name"].values.tolist())
        self.assertIn("Jane", self.reader_fake.unique_ids["first_name"].values.tolist())
        self.assertIn("John", self.reader_fake.unique_ids["first_name"].values.tolist())
        self.assertIn("Joe", self.reader_fake.unique_ids["first_name"].values.tolist())

    def test__add_filters_column(self):
        filters = [PaymentFilters.LASTNAME, PaymentFilters.CREDENTIAL]

        with_filters = ConflictedPaymentIDs.add_filters_column(
            pd.DataFrame({}), filters,
        )

        self.assertIsInstance(with_filters, pd.DataFrame)
        self.assertTrue(with_filters.empty)

        with_filters = ConflictedPaymentIDs.add_filters_column(
            pd.DataFrame({
                "profile_id": [1, 2],
                "first_name": ["John", "Jane"],
                "last_name": ["Doe", "Smith"],
            }),
            filters,
        )
        self.assertIsInstance(with_filters, pd.DataFrame)
        self.assertIn("filters", with_filters.columns)
        for i in with_filters.index:
            row = with_filters.iloc[i]
            self.assertEqual(row["filters"], filters)

        with_filters = ConflictedPaymentIDs.add_filters_column(
            pd.DataFrame({
                "profile_id": [1],
                "first_name": ["John"],
                "last_name": ["Doe"],
            }),
            filters,
        )
        self.assertIsInstance(with_filters, pd.DataFrame)
        self.assertIn("filters", with_filters.columns)
        self.assertEqual(with_filters.iloc[0]["filters"], filters)

    def test__update_unmatched(self):
        self.reader_fake.payments_x_conflicteds = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )
        self.reader_fake.update_ids(self.reader_fake.extract_unique_ids(
                self.reader_fake.payments_x_conflicteds,
            ), filters=[PaymentFilters.LASTNAME])

        unmatched = self.reader_fake.payments_x_conflicteds[
            self.reader_fake.payments_x_conflicteds["profile_id"].isna()
        ]

        self.reader_fake.update_unmatched(unmatched, Unmatcheds.NOLASTNAME)

        self.assertFalse(self.reader_fake.unmatched.empty)

        self.assertTrue((self.reader_fake.unmatched["unmatched"] == Unmatcheds.NOLASTNAME).all())

        self.assertEqual(len(self.reader_fake.unmatched), 1)

        self.assertIn("Ebalt", self.reader_fake.unmatched["last_name"].values.tolist())

        self.assertIn("Dave", self.reader_fake.unmatched["first_name"].values.tolist())

    def test__remove_conflict_prefix(self):
        un_prefixed = self.reader_fake.remove_conflict_prefix(self.fake_conflicteds)
        self.assertIn("first_name", un_prefixed.columns)
        self.assertIn("middle_initial_1", un_prefixed.columns)
        self.assertIn("middle_initial_2", un_prefixed.columns)
        self.assertIn("middle_name_1", un_prefixed.columns)
        self.assertIn("middle_name_2", un_prefixed.columns)
        self.assertIn("credentials", un_prefixed.columns)
        self.assertIn("specialtys", un_prefixed.columns)
        self.assertIn("citystates", un_prefixed.columns)
        self.assertNotIn("conflict_first_name", un_prefixed.columns)
        self.assertNotIn("conflict_middle_initial_1", un_prefixed.columns)
        self.assertNotIn("conflict_middle_initial_2", un_prefixed.columns)
        self.assertNotIn("conflict_middle_name_1", un_prefixed.columns)
        self.assertNotIn("conflict_middle_name_2", un_prefixed.columns)

    def test__check_sanity(self):
        self.reader_fake.payments_x_conflicteds = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )
        self.reader_fake.update_unmatched(
            self.reader_fake.payments_x_conflicteds[
                self.reader_fake.payments_x_conflicteds["profile_id"].isna()
            ],
            Unmatcheds.NOLASTNAME,
        )
        self.reader_fake.filter_and_update_unique_ids(
            payments_x_conflicteds=self.reader_fake.payments_x_conflicteds,
            payment_filters=[PaymentFilters.LASTNAME],
        )

        self.assertIsNone(self.reader_fake.check_sanity())

        # Remove a row from the payments DataFrame
        self.reader_fake.num_conflicteds = self.reader_fake.num_conflicteds - 1
        self.assertRaises(
            AssertionError,
            self.reader_fake.check_sanity
        )

    def test__filter_and_update_unique_ids(self):
        self.reader_fake.payments_x_conflicteds = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        pre_filter_len = len(self.reader_fake.unique_ids)

        self.reader_fake.filter_and_update_unique_ids(
            payments_x_conflicteds=self.reader_fake.payments_x_conflicteds,
            payment_filters=[PaymentFilters.CREDENTIAL],
        )

        self.assertFalse(self.reader_fake.unique_ids.empty)
        self.assertEqual(len(self.reader_fake.unique_ids), pre_filter_len+2)
        self.assertIn("Doe", self.reader_fake.unique_ids["last_name"].values.tolist())
        self.assertIn("Smith", self.reader_fake.unique_ids["last_name"].values.tolist())

    def test__filter_by_credential(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_credential(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-2)

    def test__filter_by_first_name(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_firstname(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-2)

    def test__filter_by_specialty(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_specialty(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-2)

    def test__filter_by_subspecialty(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_subspecialty(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-2)

    def test__filter_by_fullspecialty(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_fullspecialty(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-3)
        self.assertEqual(len(filtered_df.iloc[0]["specialtys"]), 1)
        self.assertIn(
            Specialtys(specialty="Internal Medicine", subspecialty=None),
            filtered_df.iloc[0]["specialtys"],
        )

    def test__filter_by_city(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_city(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-2)
        self.assertNotIn("Johnson", filtered_df["last_name"].values.tolist())

    def test__filter_by_state(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_state(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-2)
        self.assertNotIn("Smith", filtered_df["last_name"].values.tolist())

    def test__filter_by_citystate(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_citystate(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-3)
        self.assertNotIn("Johnson", filtered_df["last_name"].values.tolist())
        self.assertNotIn("Smith", filtered_df["last_name"].values.tolist())

    def test__filter_by_middle_initial(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_middle_initial(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-2)
        self.assertIn("Doe", filtered_df["last_name"].values.tolist())
        self.assertIn("Smith", filtered_df["last_name"].values.tolist())
        self.assertNotIn("Johnson", filtered_df["last_name"].values.tolist())

    def test__middle_initial_match(self):
        self.assertFalse(
            ConflictedPaymentIDs.middle_initial_match(
                conflicted_middle_initial_1=None,
                conflicted_middle_initial_2=None,
                conflicted_middle_name_1=None,
                conflicted_middle_name_2=None,
                payment_middle_name="Potter",
            )
        )
        self.assertTrue(
            ConflictedPaymentIDs.middle_initial_match(
                conflicted_middle_initial_1="P",
                conflicted_middle_initial_2=None,
                conflicted_middle_name_1=None,
                conflicted_middle_name_2=None,
                payment_middle_name="Potter",
            )
        )

    def test__middlename_match(self):
        self.assertFalse(
            ConflictedPaymentIDs.middlename_match(
                conflicted_middle_name_1=None,
                conflicted_middle_name_2=None,
                payment_middle_name="Potter",
            )
        )
        self.assertTrue(
            ConflictedPaymentIDs.middlename_match(
                conflicted_middle_name_1="Potter",
                conflicted_middle_name_2=None,
                payment_middle_name="Potter",
            )
        )
        self.assertTrue(
            ConflictedPaymentIDs.middlename_match(
                conflicted_middle_name_1=None,
                conflicted_middle_name_2="Potter",
                payment_middle_name="Potter",
            )
        )
        self.assertFalse(
            ConflictedPaymentIDs.middlename_match(
                conflicted_middle_name_1="Weasley",
                conflicted_middle_name_2=None,
                payment_middle_name="Potter",
            )
        )

    def test__filter_by_middlename(self):
        self.reader_fake.payments = self.reader_fake.merge_by_last_name(
            self.reader_fake.payments,
            self.reader_fake.conflicteds,
        )

        filtered_df = self.reader_fake.filter_by_middlename(
            self.reader_fake.payments,
        )

        pre_filter_len = len(self.reader_fake.payments)
        self.assertIsInstance(filtered_df, pd.DataFrame)
        self.assertEqual(len(filtered_df), pre_filter_len-3)
        self.assertIn("Doe", filtered_df["last_name"].values.tolist())
        self.assertNotIn("Smith", filtered_df["last_name"].values.tolist())
        self.assertNotIn("Johnson", filtered_df["last_name"].values.tolist())