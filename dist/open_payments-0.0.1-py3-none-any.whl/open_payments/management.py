import pandas as pd

from .credentials import PaymentCredentials
from .helpers import get_file_suffix, open_payments_directory
from .ids import PaymentIDs
from .payment_types import PaymentTypes
from .physicians_only import PhysicianFilter
from .specialtys import PaymentSpecialtys


def unique_credentials() -> None:
    """Creates an Excel file containing unique credentials."""

    PaymentCredentials(nrows=None, years=2023).create_unique_credentials_excel()


def MD_DO_2023_general_payments() -> None:
    """Creates an Excel file containing unique payment IDs."""

    path = open_payments_directory()

    id_maker = PaymentIDs(
        nrows=None,
        payment_classes=["general"],
        years=2023,
    )

    payments = id_maker.all_payments()

    payments = PhysicianFilter(payments).filter()

    file_suffix = get_file_suffix(id_maker.years, id_maker.payment_classes)

    with pd.ExcelWriter(
        f"{path}/MD_DO_payments{file_suffix}.xlsx",
        engine="openpyxl",
    ) as writer:
        payments.to_excel(writer, sheet_name="payments")


def unique_specialties() -> None:
    """Creates an Excel file containing unique specialties."""

    PaymentSpecialtys(nrows=None, years=2023).create_unique_specialtys_excel()


def general_payment_types() -> None:
    """Creates an Excel file containing unique payment types."""

    PaymentTypes(payment_classes="general").create_payment_types_excel()